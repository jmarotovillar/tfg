"""
Views for the Indivo "My Diabetes" app

Jaime Maroto Villar
jaime.mvillar@alumnos.upm.es
"""

from utils import *
import uuid
from django.utils import simplejson
import urllib2
from xml.etree import ElementTree
import settings
from django.contrib.messages import constants as messages


#------------------SMART LIBRARIES IMPORT-------------------
from smart_client_python.client import SMARTClient

# SMART Container OAuth Endpoint Configuration
_ENDPOINT = settings.ENDPOINT

# Global variables
ISO_8601_DATETIME = '%Y-%m-%d'
last_pill_dates = {}
Global_PATIENT_ID = 0
Global_ADHERE_VARS = 0

#---------------------------------------------------------

LAB_STATUSES = {
    'correction': 'Correction',
    'preliminary': 'Preliminary',
    'final': 'Final',
}

#===================================================
#                  OAUTH
#===================================================
def start_auth(request):
    """
    begin the oAuth protocol with the server
    
    expects either a record_id or carenet_id parameter,
    now that we are carenet-aware
    """

    # create the client to Indivo
    client = get_indivo_client(request, with_session_token=False)
 
    
    # do we have a record_id?
    record_id = request.GET.get('record_id', None)
    carenet_id = request.GET.get('carenet_id', None)
    
    # prepare request token parameters
    params = {'oauth_callback':'oob'}
    if record_id:
        params['indivo_record_id'] = record_id
    if carenet_id:
        params['indivo_carenet_id'] = carenet_id

    # request a request token
    req_token = client.fetch_request_token(params)

    # store the request token in the session for when we return from auth
    request.session['request_token'] = req_token

    
    # redirect to the UI server
    return HttpResponseRedirect(client.auth_redirect_url)

def after_auth(request):
    """
    after Indivo authorization, exchange the request token for an access token and store it in the web session.
    """
    # get the token and verifier from the URL parameters
    oauth_token, oauth_verifier = request.GET['oauth_token'], request.GET['oauth_verifier']
    
    # retrieve request token stored in the session
    token_in_session = request.session['request_token']
    
    # is this the right token?
    if token_in_session['oauth_token'] != oauth_token:
        return HttpResponse("oh oh bad token")
    
    # get the indivo client and use the request token as the token for the exchange
    client = get_indivo_client(request, with_session_token=False)
     
    client.update_token(token_in_session)
    access_token = client.exchange_token(oauth_verifier)
    
    # store stuff in the session
    request.session['access_token'] = access_token
    
    if access_token.has_key('xoauth_indivo_record_id'):
        request.session['record_id'] = access_token['xoauth_indivo_record_id']
        if request.session.has_key('carenet_id'):
            del request.session['carenet_id']
    else:
        if request.session.has_key('record_id'):
            del request.session['record_id']
        request.session['carenet_id'] = access_token['xoauth_indivo_carenet_id']
    
    # go to the index screen 
    return HttpResponseRedirect(reverse(index))

#===================================================
# Convenience function to get oa_params and ret
# variables from the SmartClient and return them.
#===================================================
def get_smart_client(record_id):
    """ Initialize a new SmartClient and return it """

    try:
        client = SMARTClient(_ENDPOINT.get('app_id'),
                             _ENDPOINT.get('url'),
                             _ENDPOINT)
    except Exception as e:
        raise Exception('Could not init SMARTClient: %s' % e)
        return

    client.record_id = record_id
    return client

#========================================
#             INDEX 
#========================================

#Index screen. This method loads the record of the patient
def index(request):
    #creating the client
    client = get_indivo_client(request)
  
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
     
     #If patient doesn't belong the any carenet
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
    
    #Getting the name of the patient 
   # record_id = request.session['record_id']
   # resp, content = client.record(record_id=record_id)
   # if resp['status'] != '200':
            # TODO: handle errors
   #         raise Exception("Error reading Record info: %s"%content)
   # record = parse_xml(content)
    
    record_label = record.attrib['label']
    record_id=''
    #Going to the index screen
    return render_template('index',{'record_label': record_label,'record_id': record_id,'in_carenet':in_carenet, })

#=============================================
#             MY DIABETES MANAGER
#=============================================

#Diabetes manager screen
def diabetes_manager(request):
    return render_template('diabetes_manager')


#--------------------------------------
#        INSULIN
#-------------------------------------

def insulin(request):
    return medication_list(request,'insulin')


#This method defines an insulin manager able to read and write insulin-related data.
def new_insulin(request):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)
   
    if request.method == "GET":
        return render_template('new_insulin')
    else:

        # Fix dates formatted by JQuery into xs:dateTime                                        
        date = request.POST['date'] + 'T00:00:00Z' if request.POST['date'] != '' else ''
        
      
        try:     
            value=float(request.POST['value'])
                  
        except:
            
            return render_template('insulin',{'message': 'Error: Value and frequency must be numeric values'})
        
        
      
        # get the variables and create a new LabResult XML
        params = {'name':request.POST['name'],
                  'id':'insulin_intake',
                  'time_period': request.POST['time']+' ('+request.POST['time_period']+')',
                  'value': value,
                  'unit':'unit',
                  'date':date,
                  'date':date,
                  'instructions':request.POST['instructions'],
                  'taken_by':record.attrib['label']} 
                  
                  
        insulin_xml = render_raw('medication', params, type='xml')
        
        # add the insulin
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=insulin_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new insulin intake: %s"%content)
        
        return HttpResponseRedirect(reverse(insulin))
        
         

#-------------------------------------
#        GLUCOSE
#-------------------------------------

#This method defines a glucose manager able to read and write glucose-related data.
def glucose(request):
    return labList(request,'glucose_manager')

def new_glucose(request):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)

    if request.method == "GET":
        return render_template('new_glucose')
    else:

        # Fix dates formatted by JQuery into xs:dateTime                                        
        date = request.POST['date']  if request.POST['date'] != '' else ''
        
        # Fixed data
        unit='mg/dL'
      
        try:
          
                 value=float(request.POST['value'])
        except:
            
            return render_template('new_glucose',{'message': 'Error: Value must be a numeric value'})
        
        if value < 90 or value > 180:
          abnormality='Out of Range'
        else:
          abnormality='In Range'
      
        # get the variables and create a new LabResult XML
        params = {'name':'Glucose',
                  'id':'glucose_result',
                  'date': date, 
                  'comments' : request.POST['comments'],
                  'value': value,
                  'unit':unit,
                  'max_value':'180',
                  'unit':unit,
                  'min_value':'90',
                  'unit':unit,
                  'collected_by':record.attrib['label'],
                  'abnormality':abnormality,
                  'time':request.POST['time']+' ('+request.POST['time_moment']+' '+request.POST['time_period']+')'} 
                  
                  
        labResult_xml = render_raw('blood_test', params, type='xml')
        
        # add the glucose test
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=labResult_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new blood test: %s"%content)
        
        return HttpResponseRedirect(reverse(glucose))


#--------------------------------------
#       MEAL MANAGER
#-------------------------------------
def meal(request):
   return meal_list(request)

def new_meal(request):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)

    if request.method == "GET":
        return render_template('new_meal')
    else:

        # Fix dates formatted by JQuery into xs:dateTime                                        
        date = request.POST['date'] + 'T00:00:00Z' if request.POST['date'] != '' else ''
        
      
        try:     
          
            cho_bev=float(request.POST['cho_bev'])
            cho_d1=float(request.POST['cho_d1'])
            cho_d2=float(request.POST['cho_d2'])
            cho_d3=float(request.POST['cho_d3'])
                     
        except:
            
            return render_template('new_meal',{'message': 'Error: CHO must be numeric values'})
        
        total_cho=cho_bev+cho_d1+cho_d2+cho_d3;
      
        # get the variables and create a new meal XML
        params = {
                  'id':'meal',
                  'date':date,
                  'time_period':request.POST['time']+' ('+request.POST['time_period']+')',
                  'cho':total_cho,
                  'beverage_name': request.POST['beverage'],
                  'first_dish_name':request.POST['name_first'],
                  'second_dish_name':request.POST['name_second'],
                  'dessert_name':request.POST['name_dessert'],
                  'posted_by':record.attrib['label']} 
                  
                  
        meal_xml = render_raw('meal', params, type='xml')
        
    

        # adding the meal
        resp, content = client.document_create(record_id=request.session['record_id'], body=meal_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new meal: %s"%content)
       
       
        return HttpResponseRedirect(reverse(diabetes_manager))

def meal_list(request):

    #creating the client
    client = get_indivo_client(request)
    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
       
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read problems
        resp, content = client.generic_list(record_id=record_id, data_model="Meal")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        meals = simplejson.loads(content)
       
    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read problems from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="Meal")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        meals = simplejson.loads(content)
        
    meals = map(process_meal, meals)
    record_label = record.attrib['label']
    num_meals = len(meals)
    
    #Going to the comorbidity list screen
    return render_template('meal_manager', {'record_label': record_label, 'num_meals' : num_meals, 
                                    'meals': meals, 'in_carenet':in_carenet, })
     

def one_meal(request,meal_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
  
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=meal_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=meal_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=meal_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=meal_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    meal = parse_sdmx_lab(doc, ns=True)
    
    if doc_meta_xml:
         doc_meta = parse_xml(doc_meta_xml)
         meta = parse_meta(doc_meta) 
    else:
         meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_meal', {'meal':meal, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'meal_id': meal_id, 'surl_credentials': surl_credentials})



#--------------------------------------
#       PHYSICAL ACTIVITY MANAGER
#-------------------------------------

def physical_activity(request):
    return physical_activity_list(request)


def new_physical_activity(request):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)


    if request.method == "GET":
        return render_template('physical_activity')
    else:

        # Fix dates formatted by JQuery into xs:dateTime                                        
        date = request.POST['date'] + 'T00:00:00Z' if request.POST['date'] != '' else ''
        
      
        try:     
            duration=float(request.POST['duration'])
     
        except:
            
            return render_template('physical_activity',{'message': 'Error: Duration must be a numeric value'})
        
       
      
        # get the variables and create a new physical activity XML
        params = {
                  
                  'name':request.POST['name'],
                  'duration':duration,
                  'intensity':request.POST['intensity'],
                  'date': request.POST['date'],
                  'time':request.POST['time'],
                  'comments':request.POST['comments'],
                  'posted_by':record.attrib['label']} 
        
        physical_activity_xml = render_raw('physical_activity', params, type='xml')
        
        # add the activity
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=physical_activity_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new activity: %s"%content)
        
        return HttpResponseRedirect(reverse(diabetes_manager))


def physical_activity_list(request):
    #creating the client
    client = get_indivo_client(request)
    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
       
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read problems
        resp, content = client.generic_list(record_id=record_id, data_model="Physical_activity")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        activities = simplejson.loads(content)
       
    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read problems from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="Physical_activity")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        activities = simplejson.loads(content)
        
    activities = map(process_activity, activities)
    record_label = record.attrib['label']
    num_acts = len(activities)
    
    #Going to the comorbidity list screen
    return render_template('physical_activity_manager', {'record_label': record_label, 'num_acts' : num_acts, 
                                    'activities': activities, 'in_carenet':in_carenet, })

def one_physical_activity(request,physical_activity_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
  
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=physical_activity_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=physical_activity_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=physical_activity_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=physical_activity_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    physical_activity = parse_sdmx_lab(doc, ns=True)
    
    if doc_meta_xml:
         doc_meta = parse_xml(doc_meta_xml)
         meta = parse_meta(doc_meta) 
    else:
         meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_physical_activity', {'physical_activity':physical_activity, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'physical_activity_id': physical_activity_id, 'surl_credentials': surl_credentials})
#============================================
#               CLINICIAN DATA
#===========================================

#Clinician Data screen
def clinician_data(request):
    return render_template('clinician_data')

#--------------------------------------
#         COMORBIDITIES
#-------------------------------------

#Defines a list of comorbidities
def problem_list(request):
    #creating the client
    client = get_indivo_client(request)
    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
       
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read problems
        resp, content = client.generic_list(record_id=record_id, data_model="Problem")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        probs = simplejson.loads(content)

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read problems from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="Problem")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        probs = simplejson.loads(content)
        
    probs = map(process_problem, probs)
    record_label = record.attrib['label']
    num_problems = len(probs)
    
    #Going to the comorbidity list screen
    return render_template('list', {'record_label': record_label, 'num_problems' : num_problems, 
                                    'problems': probs, 'in_carenet':in_carenet, })

#This method defines a new comorbidity
def new_problem(request):

    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)

    if request.method == "GET":
        return render_template('newproblem')
    else:

        # Fix dates formatted by JQuery into xs:dateTime                                        
        date_onset = request.POST['date_onset'] + 'T00:00:00Z' if request.POST['date_onset'] != '' else ''
        date_resolution = request.POST['date_resolution'] + 'T00:00:00Z' if request.POST['date_resolution'] != '' else ''

        # get the variables and create a problem XML
        params = {'code_abbrev':'', 
                  'coding_system': 'http://purl.bioontology.org/ontology/SNOMEDCT/', 
                  'date_onset': date_onset, 
                  'date_resolution': date_resolution, 
                  'code_fullname': request.POST['code_fullname'], 
                  'code': 'new_comorbidity', 
                  'comments' : request.POST['comments'],
                  'posted_by':record.attrib['label']}
        problem_xml = render_raw('problem', params, type='xml')
        
        # add the problem
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=problem_xml, 
                                               content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new problem: %s"%content)
        
        return HttpResponseRedirect(reverse(problem_list))

#Method that autocompletes the name of the comorbidities
def code_lookup(request):
    client = get_indivo_client(request)
    
    query = request.GET['query']
    
    # reformat this for the jQuery autocompleter
    resp, content = client.coding_system_query(system_short_name='snomed', body={'q':query})
    if resp['status'] != '200':
        # TODO: handle errors
        # But this Indivo instance might not support codingsystem lookup, so let's pass
        pass
    codes = simplejson.loads(content)
    formatted_codes = {'query': query, 'suggestions': [c['consumer_value'] for c in codes], 'data': codes}
    
    return HttpResponse(simplejson.dumps(formatted_codes), mimetype="text/plain")

def one_problem(request, problem_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=problem_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=problem_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=problem_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=problem_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    problem = parse_sdmx_problem(doc, ns=True)
    
    if doc_meta_xml:
        doc_meta = parse_xml(doc_meta_xml)
        meta = parse_meta(doc_meta)
    else:
        meta = None
    
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one', {'problem':problem, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'problem_id': problem_id, 'surl_credentials': surl_credentials})



#--------------------------------------
#       MEDICATION
#-------------------------------------


#This method defines a medication list
def medications(request):
    return medication_list(request,'medications')


def medication_list(request,template):
    client = get_indivo_client(request)
    
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read medications
        resp, content = client.generic_list(record_id=record_id, data_model="Medication")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        meds = simplejson.loads(content)

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read problems from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="Medication")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        meds = simplejson.loads(content)
        
    meds = map(process_medication, meds)
    record_label = record.attrib['label']
    num_meds = len(meds)
    
    #Going to the medications screen
    return render_template(template, {'record_label': record_label, 'num_meds' : num_meds, 
                                    'medications': meds, 'in_carenet':in_carenet, })

def one_medication(request, medication_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=medication_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=medication_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=medication_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=medication_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    medication = parse_sdmx_med(doc, ns=True)
    
    if doc_meta_xml:
       doc_meta = parse_xml(doc_meta_xml)
       meta = parse_meta(doc_meta)
    else:
       meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_medication', {'medication':medication, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'medication_id': medication_id, 'surl_credentials': surl_credentials})

#--------------------------------------
#        LAB RESULTS
#-------------------------------------


#This method allows the patient to visualize lab-data related to diabetes (glucose, HbA1c,etc.)
def labResults(request):
    template='labResults'
    return labList(request,template)

    

#This method defines a laboratory result list.
def labList(request,template):
    #creating the client
    client = get_indivo_client(request)
    
    # read in query params
    limit = int(request.GET.get('limit', 15))
    offset = int(request.GET.get('offset', 0))
    order_by = request.GET.get('order_by', 'date') # name_code_title, created_at, date
    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read lab results
        resp, content = client.generic_list(record_id=record_id, data_model="LabResult")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        labs = simplejson.loads(content)

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read lab results from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="LabResult")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        labs = simplejson.loads(content)
        
    labs = map(process_labResult, labs)
    record_label = record.attrib['label']
    num_labs = len(labs)
    
    #Going to the lab results list screen
    return render_template(template, {
                                      'record_label': record_label, 
                                      'num_labs' : num_labs, 
                                      'labResults': labs, 
                                      'in_carenet':in_carenet,
                                      'order_by': order_by,
                                      'limit': limit,
                                      'offset': offset})


def one_labResult(request, labResult_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
  
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=labResult_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=labResult_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=labResult_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=labResult_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    labResult = parse_sdmx_lab(doc, ns=True)
    
    if doc_meta_xml:
       doc_meta = parse_xml(doc_meta_xml)
       meta = parse_meta(doc_meta)
    else:
       meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_labResult', {'labResult':labResult, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'labResult_id': labResult_id, 'surl_credentials': surl_credentials})

#===========================================
#             INFORMATION
#==========================================


#Information screen
def information(request):
    return render_template('information')


#Education screen
def education(request):
    return render_template('education')

#About screen
def about(request):
    return render_template('about')


#This method loads useful information for the patient (emails, phone numbers,etc.)
def useful_Information(request):
     #creating the client
    client = get_indivo_client(request)

    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read lab results
        resp, content = client.generic_list(record_id=record_id, data_model="Contact")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        contacts = simplejson.loads(content)
       
    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read lab results from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="Contact")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        contacts = simplejson.loads(content)
        
    contacts = map(process_contact, contacts)
    record_label = record.attrib['label']
    num_contacts = len(contacts)
    
    #Going to the event list screen
    return render_template('useful_Info', {'record_label': record_label, 'num_contacts' : num_contacts, 
                                    'contacts': contacts, 'in_carenet':in_carenet })

#This method creates a new contact 
def new_contact(request):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)

    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)

    if request.method == "GET":
        return render_template('new_contact')
    else:

        # get the variables and create a contact XML
        params = {
                  'status':request.POST['status'], 
                  'name':request.POST['name'],
                  'lastname':request.POST['lastname'],  
                  'telephone':request.POST['telephone'], 
                  'cellphone':request.POST['cellphone'], 
                  'email':request.POST['email'], 
                  'street':request.POST['street'],
                  'city':request.POST['city'],
                  'postalcode':request.POST['postalcode'],
                  'country':request.POST['country'],
                  'posted_by':record.attrib['label']}
        
        contact_xml = render_raw('contact', params, type='xml')
    
        # add the contact
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=contact_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new contact: %s"%content)
        return HttpResponseRedirect(reverse(useful_Information))


def one_contact(request,contact_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
  
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=contact_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=contact_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=contact_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=contact_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    contact = parse_sdmx_lab(doc, ns=True)
    
    if doc_meta_xml:
         doc_meta = parse_xml(doc_meta_xml)
         meta = parse_meta(doc_meta) 
    else:
         meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_contact', {'contact':contact, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'contact_id': contact_id, 'surl_credentials': surl_credentials})

#===========================================
#             EVENTS
#==========================================


#This method loads event information for the patient 
def event(request, template):
     #creating the client
    client = get_indivo_client(request)

    
    #True if the patient belongs to any carenet
    in_carenet = request.session.has_key('carenet_id')
    if not in_carenet:
        # get record info
        record_id = request.session['record_id']
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read lab results
        resp, content = client.generic_list(record_id=record_id, data_model="SimpleClinicalNote")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems: %s"%content)
        events = simplejson.loads(content)
       
    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)

        # read lab results from the carenet
        resp, content = client.carenet_generic_list(carenet_id=carenet_id, data_model="SimpleClinicalNote")
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading problems from carenet: %s"%content)
        events = simplejson.loads(content)
        
    events = map(process_event, events)
    record_label = record.attrib['label']
    num_events = len(events)
    
    #Going to the event list screen
    return render_template(template, {'record_label': record_label, 'num_events' : num_events, 
                                    'events': events, 'in_carenet':in_carenet })


#This method shows a single event for further information and for carenet sharing
def one_event(request,event_id):
    client = get_indivo_client(request)
    record_id = request.session.get('record_id', None)
  
    
    if record_id:
        # get record info
        resp, content = client.record(record_id=record_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.record_specific_document(record_id=record_id, document_id=event_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.record_document_meta(record_id=record_id, document_id=event_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata: %s"%content)
        doc_meta_xml = content

    else:
        # get record info
        carenet_id = request.session['carenet_id']
        resp, content = client.carenet_record(carenet_id=carenet_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error reading Record info: %s"%content)
        record = parse_xml(content)
        
        # read the document
        resp, content = client.carenet_document(carenet_id=carenet_id, document_id=event_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document from carenet: %s"%content)
        doc_xml = content

        # read the document's metadata
        resp, content = client.carenet_document_meta(carenet_id=carenet_id, document_id=event_id)
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error fetching document metadata from carenet: %s"%content)
        doc_meta_xml = content
    
    doc = parse_xml(doc_xml)    
    event = parse_sdmx_lab(doc, ns=True)
    
    if doc_meta_xml:
         doc_meta = parse_xml(doc_meta_xml)
         meta = parse_meta(doc_meta) 
    else:
         meta = None
  
    record_label = record.attrib['label']
    surl_credentials = client.get_surl_credentials()
    
    return render_template('one_event', {'event':event, 'record_label': record_label, 'meta': meta, 'record_id': record_id, 'event_id': event_id, 'surl_credentials': surl_credentials})


#This method creates a new event
def new_event(request,id,template):
    # creating the client
    client = get_indivo_client(request)

    # Saving the record to get the name
    record_id=request.session['record_id']
    resp, content = client.record(record_id=record_id)
    if resp['status'] != '200':
          # TODO: handle errors
          raise Exception("Error reading Record info: %s"%content)
    record = parse_xml(content)
    if request.method == "GET":
        return render_template('new_event',{'id':id})
    else:
        
        if id == "medical_appointment":
           name= "Medical Appointment"
        else:
           name=request.POST['name']

        # get the variables and create a contact XML
        params = {
                  'id':id, 
                  'name':name,
                  'date':request.POST['date'],  
                  'time':request.POST['time'], 
                  'comments':request.POST['comments'], 
                  'inserted_by':record.attrib['label']}
        
        event_xml = render_raw('event', params, type='xml')
    
        # add the event
        client = get_indivo_client(request)
        resp, content = client.document_create(record_id=request.session['record_id'], body=event_xml, content_type='application/xml')
        if resp['status'] != '200':
            # TODO: handle errors
            raise Exception("Error creating new contact: %s"%content)
        return HttpResponseRedirect(reverse(event_dashboard))


#This method shows the event dashboard
def event_dashboard(request):
    return render_template('event_dashboard')

# Method that shows a list of medical appointments

def medical_appointment(request):
   return event(request,'medical_appointment_manager')
#Method to create a medical appointment

def new_medical_appointment(request):
    return new_event(request,'medical_appointment','medical_appointment_manager')


#Method that shows a list of "other events"
def other_events(request):
    return event(request,'other_event_manager')

#Method that creates other kind of events
def new_other_event(request):
    return new_event(request, 'other','other_event_manager')

