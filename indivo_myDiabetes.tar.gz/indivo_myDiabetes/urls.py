from django.conf.urls.defaults import *
from views import *
from django.conf import settings

urlpatterns = patterns('',
   # authentication
   (r'^start_auth', start_auth),
   (r'^after_auth', after_auth),
   
   #Index
   (r'^smartapp/index.html', index),
   (r'^index', index),
  

  
#------------------------------------
#        CLINICIAN DATA URLS
#------------------------------------
   (r'^clinician_data',clinician_data),
 
   #Comorbidities
   (r'^problems/$', problem_list),
   (r'^problems/new$', new_problem),
   (r'^problems/(?P<problem_id>[^/]+)', one_problem),
   (r'^problems/codelookup$', code_lookup),

   #Medication 
   (r'^medications/$',medications),
   (r'^medications/(?P<medication_id>[^/]+)', one_medication),

   #Laboratory Results
   (r'^labResults/$',labResults),
   (r'^labResults/(?P<labResult_id>[^/]+)', one_labResult),



#-------------------------------------
#     DIABETES MANAGER URLS
#-------------------------------------
   (r'^diabetes_manager/$',diabetes_manager),
  

   #Insulin manager
   (r'^insulin/$',insulin),
   (r'^new_insulin',new_insulin),
   (r'^insulin/(?P<medication_id>[^/]+)', one_medication),

   #Glucose manager
   (r'^glucose/$',glucose),
   (r'^new_glucose',new_glucose),
   (r'^glucose/(?P<labResult_id>[^/]+)', one_labResult),

   #Meal manager
   (r'^meal/$',meal), 
   (r'^new_meal',new_meal),
   (r'meal/(?P<meal_id>[^/]+)', one_meal),

   #Physical activity manager
   (r'^physical_activity/$', physical_activity),
   (r'^new_physical_activity',new_physical_activity),
   (r'^physical_activity/(?P<physical_activity_id>[^/]+)',one_physical_activity),

#-------------------------------------
#       INFORMATION URLS      
#-------------------------------------
   (r'^information',information),

   #Education
   (r'^education',education),

   #Useful Information
   (r'^useful_Info/$',useful_Information),
   (r'^new_contact',new_contact),
   (r'^useful_Info/(?P<contact_id>[^/]+)',one_contact),
   
   #About
   (r'^about', about),

#-------------------------------------
#       EVENT URLS      
#-------------------------------------
   
   #Events dashboard
   (r'^event_dashboard', event_dashboard),

   #Medical Appointments
   (r'^medical_appointments_manager/$',medical_appointment),
   (r'^new_medical_appointment',new_medical_appointment),
   (r'^medical_appointments_manager/(?P<event_id>[^/]+)',one_event),

    #Other events
   (r'^other_events_manager/$',other_events),
   (r'^new_other_event',new_other_event),
   (r'^other_events_manager/(?P<event_id>[^/]+)',one_event),

    # static
    ## WARNING NOT FOR PRODUCTION
   (r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.STATIC_HOME}),
)
