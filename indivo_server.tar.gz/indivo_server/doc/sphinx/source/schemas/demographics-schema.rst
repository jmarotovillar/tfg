Indivo Document Demographics Schema
===================================

Schema:

.. include:: /../../../indivo/schemas/data/core/demographics/schema.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/data/core/demographics/demographics.xml
   :literal:
