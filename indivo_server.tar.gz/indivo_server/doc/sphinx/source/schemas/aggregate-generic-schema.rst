Indivo Generic Aggregate Reports Schema
=======================================

This schema describes report items returned in XML aggregate form from 
:doc:`Generic Reports <../generic-reports>`.

Schema:

.. include:: /../../../indivo/schemas/data/output/genericaggregatereport/genericaggregatereport.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/data/output/genericaggregatereport/genericaggregatereport.xml
   :literal:
