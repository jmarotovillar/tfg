Indivo Inbox Message Schema
===========================

Indivo messages, sent to accounts (sometimes via a record), are 
represented with the following schema.

Schema:

.. include:: /../../../indivo/schemas/metadata/message/message.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/message/message.xml
   :literal:

Another Example:

.. include:: /../../../indivo/schemas/metadata/message/message2.xml
   :literal:

