Indivo Account Schema
=====================

An Indivo Account represents a single user of the system, with their basic info and the ways in which they authenticate. 
It is separate from a record.

Schema:

.. include:: /../../../indivo/schemas/metadata/account/account.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/account/account.xml
   :literal:
