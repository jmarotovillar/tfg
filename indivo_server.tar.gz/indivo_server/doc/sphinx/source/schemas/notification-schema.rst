Indivo Notification Schema
==========================

The Indivo Healthfeed includes notifications, represented by this schema:

Schema:

.. include:: /../../../indivo/schemas/metadata/notification/notification.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/notification/notification.xml
   :literal:
