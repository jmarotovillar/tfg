Indivo Reporting Schema
=======================

See the schema for :doc:`metadata-schema` and specific 
:ref:`indivo:doc schemas <medical-schemas>`.

Schema:

.. include:: /../../../indivo/schemas/data/output/reporting/reporting.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/data/output/reporting/reporting.xml
   :literal:
