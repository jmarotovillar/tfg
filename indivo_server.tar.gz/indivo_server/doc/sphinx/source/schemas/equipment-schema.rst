Indivo Document Schema: Equipment
=================================

Schema:

.. include:: /../../../indivo/schemas/data/core/equipment/schema.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/data/core/equipment/equipment.xml
   :literal:
