Indivo Request Token Schema
===========================

The Indivo UI Server needs to manage request tokens for apps 
so that it can display the appropriate authorization screens.
This schema makes use of the :doc:`pha-schema`.

Schema:

.. include:: /../../../indivo/schemas/metadata/requesttoken/requesttoken.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/requesttoken/requesttoken.xml
   :literal:
