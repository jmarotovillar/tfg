Indivo Aggregate Report Schema
==============================

This schema describes report items returned in aggregate form.

Schema:

.. include:: /../../../indivo/schemas/data/output/aggregatereport/aggregatereport.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/data/output/aggregatereport/aggregatereport.xml
   :literal:
