Indivo Permissions Schema
=========================

Coming Soon...
