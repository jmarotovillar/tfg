Indivo Document Status History Schema
=====================================

When a document's status changes (archived, etc..), its history of changes is documented 
and available in this schema.

Schema:

.. include:: /../../../indivo/schemas/metadata/statushistory/statushistory.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/statushistory/statushistory.xml
   :literal:
