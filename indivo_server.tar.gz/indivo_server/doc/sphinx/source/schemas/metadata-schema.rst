.. _metadata-schema:

Indivo Document Metadata Schema
===============================

Schema:

.. include:: /../../../indivo/schemas/metadata/doc-metadata/metadata.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/doc-metadata/metadata.xml
   :literal:
