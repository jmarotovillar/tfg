Indivo Provider Schema
======================

A provider is typically an MD with an institution affiliation.

Schema:

.. include:: /../../../indivo/schemas/data/common/provider.xsd
   :literal:
