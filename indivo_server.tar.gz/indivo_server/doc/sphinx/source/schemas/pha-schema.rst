Indivo PHA Schema
=================

Information describing a Personal Health App (User App).
Can be wrapped into a set of Apps.


Schema:

.. include:: /../../../indivo/schemas/metadata/pha/pha.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/pha/pha.xml
   :literal:

Example of multiple apps:

.. include:: /../../../indivo/schemas/metadata/pha/phas.xml
   :literal:
