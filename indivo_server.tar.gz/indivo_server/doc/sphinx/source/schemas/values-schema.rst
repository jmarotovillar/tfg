Indivo Data Values Schema
=========================

Schema:

.. include:: /../../../indivo/schemas/data/common/values.xsd
   :literal:
