Indivo Record Schema
====================

The basic info for an Indivo record. Some of the attributes 
are there for indicating sharing relationships.

Schema:

.. include:: /../../../indivo/schemas/metadata/record/record.xsd
   :literal:

Example:

.. include:: /../../../indivo/schemas/metadata/record/record.xml
   :literal:
