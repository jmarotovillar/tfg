changing readme file
