TEST_DOCUMENT_PROCESSING_DOCS = ['''<TestMed xmlns="http://indivo.org/vocab/xml/documents#">
    <dateStarted>2010-10-01T00:00:00Z</dateStarted>
    <name>med1</name>
    <brandName>Advil</brandName>
    <frequency>2</frequency>
    <Prescription>
        <prescribedByName>Kenneth D. Mandl</prescribedByName>
        <prescribedOn>2010-09-30T00:00:00Z</prescribedOn>
    </Prescription>
    <TestFills>
        <TestFill>
            <dateFilled>2010-10-01T00:00:00Z</dateFilled>
            <supplyDays>30</supplyDays>
        </TestFill>
        <TestFill>
            <dateFilled>2010-10-16T00:00:00Z</dateFilled>
            <supplyDays>30</supplyDays>
        </TestFill>
    </TestFills>
</TestMed>''']
