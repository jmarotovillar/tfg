# Test Sequence

ts = [ 
{ 'test' : 1, 'name' : 'Auditing',                  'func' : 'test_auditing'},
{ 'test' : 1, 'name' : 'Binary Document Test',      'func' : 'test_binary_document_handling'},
{ 'test' : 1, 'name' : 'Document Handling Test',    'func' : 'test_document_handling'},
{ 'test' : 1, 'name' : 'Document Metadata Test',    'func' : 'test_document_metadata'},
{ 'test' : 1, 'name' : 'Document Processing Test',  'func' : 'test_document_processing'},
{ 'test' : 1, 'name' : 'Messaging',                 'func' : 'test_messaging'},
{ 'test' : 1, 'name' : 'OAuthing',                  'func' : 'test_oauthing'},
{ 'test' : 1, 'name' : 'PHA Document Handling',     'func' : 'test_userapp_document_handling'},
{ 'test' : 1, 'name' : 'PHAing app delete',         'func' : 'test_pha_delete'},
{ 'test' : 1, 'name' : 'PHAing record_app delete',  'func' : 'test_record_pha_delete'},
{ 'test' : 1, 'name' : 'Record Shares',             'func' : 'test_record_shares'},
{ 'test' : 1, 'name' : 'Sharing',                   'func' : 'test_sharing'},
{ 'test' : 1, 'name' : 'Special Document Handling', 'func' : 'test_special_document_handling'},
{ 'test' : 1, 'name' : 'Accounting', 'func' : 'test_account'},
{ 'test' : 1, 'name' : 'AppSpecific', 'func' : 'test_appspecific'},
{ 'test' : 1, 'name' : 'Security', 'func' : 'test_security'},
]

# to test only one
#ts = [ 
#    { 'test' : 1, 'name' : 'Document Handling Test',    'func' : 'test_document_handling'},
#    { 'test' : 1, 'name' : 'Sharing', 'func' : 'test_sharing'},
#    ]
