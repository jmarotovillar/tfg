from indivo.models import Fact
from django.db import models

class Meal(Fact):
     meal_id=models.CharField(max_length=255, null=True)
     date = models.DateTimeField(null=True)
     time_period = models.CharField(max_length=255, null=True)
     time=models.CharField(max_length=255, null=True)
     cho=models.CharField(max_length=255, null=True)
     comments = models.CharField(max_length=600, null=True)
     posted_by=models.CharField(max_length=225, null=True)

     first_dish_name = models.CharField(max_length=255, null=True)
     first_quantity_value = models.CharField(max_length=255, null=True) 
     first_quantity_unit = models.CharField(max_length=255, null=True)

     second_dish_name = models.CharField(max_length=255, null=True)
     second_quantity_value = models.CharField(max_length=255, null=True) 
     second_quantity_unit = models.CharField(max_length=255, null=True)


     dessert_name = models.CharField(max_length=255, null=True)
     dessert_quantity_value = models.CharField(max_length=255, null=True) 
     dessert_quantity_unit = models.CharField(max_length=255, null=True)


     beverage_name = models.CharField(max_length=225, null=True)
     quantity_value = models.CharField(max_length=255, null=True) 
     quantity_unit = models.CharField(max_length=255, null=True)
