from indivo.models import Fact
from django.db import models

class Physical_activity(Fact):
     
     name = models.CharField(max_length=255, null=True)
     duration = models.CharField(max_length=255, null=True) 
     intensity = models.CharField(max_length=255, null=True)
     date = models.DateTimeField(null=True)
     time=models.CharField(max_length=255, null=True)
     posted_by=models.CharField(max_length=225, null=True)
     comments = models.CharField(max_length=600, null=True)
