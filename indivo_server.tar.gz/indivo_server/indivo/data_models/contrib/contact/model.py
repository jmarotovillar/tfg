from indivo.models import Fact
from django.db import models


class Contact(Fact):
     status=models.CharField(max_length=255, null=True)
     name = models.CharField(max_length=225,null=True)
     lastname = models.CharField(max_length=225,null=True)
     telephone = models.CharField(max_length=255, null=True)
     cellphone = models.CharField(max_length=255,null=True)
     email = models.CharField(max_length=225, null=True)
     street = models.CharField(max_length=225, null=True)
     city = models.CharField(max_length=225, null=True)
     postalcode = models.CharField(max_length=225, null=True)
     country = models.CharField(max_length=225, null=True)
     posted_by=models.CharField(max_length=225, null=True)
