-- create a temp table to hold everything
create table temp_hl7_v3_complete (
    hl7_cid 			 varchar(50),
    name      varchar(250),
    description varchar(500),
    umls_cui				 varchar(50)
);

